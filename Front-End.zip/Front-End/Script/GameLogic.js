


let player1Health = 3;
let player2Health = 3;

const healthBarP1 = document.getElementById("p1-score");

console.log(healthBarP1.innerHTML)

let currentPlayer = 1;


