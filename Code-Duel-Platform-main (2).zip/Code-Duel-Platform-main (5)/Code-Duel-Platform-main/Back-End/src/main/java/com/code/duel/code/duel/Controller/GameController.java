package com.code.duel.code.duel.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class GameController {

//    @Autowired
//    SubmissionService submissionService;
//
//    @PostMapping("/submit") // www.codeduel.com/submit
//    public Submission submit(SubmissionRequestMapper submissionRequestMapper){
//        submissionService.submit(submissionRequestMapper);
//    }
}
