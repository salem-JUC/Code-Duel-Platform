package com.code.duel.code.duel.Model;

public enum Role {
    ADMIN, PLAYER
}
