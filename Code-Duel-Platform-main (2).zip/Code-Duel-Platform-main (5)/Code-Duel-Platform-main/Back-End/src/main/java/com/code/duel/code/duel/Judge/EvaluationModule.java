package com.code.duel.code.duel.Judge;

import com.code.duel.code.duel.Model.Submission;
import com.code.duel.code.duel.Model.TestCase;

import java.util.List;


public class EvaluationModule {

    Judge0Wrapper judge0Wrapper;
//    public Submission evaluate(Submission submission , List<TestCase> testCases){
//        submission.getCode();
//
//        for (int i = 0; i < testCases.size(); i++) {
//            // call judge-wrapper.submit()
//        }
//    }
}
