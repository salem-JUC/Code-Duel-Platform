package com.code.duel.code.duel.Service;

import org.springframework.stereotype.Service;

@Service
public class AdminService {
}
