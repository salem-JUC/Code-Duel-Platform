package com.code.duel.code.duel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeDuelApplicationTests {

	@Test
	void contextLoads() {
	}

}
