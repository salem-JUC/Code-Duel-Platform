package com.code.duel.code.duel.Controller;

import com.code.duel.code.duel.Model.Submission;
import com.code.duel.code.duel.RequestMapper.SubmissionRequestMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class GameController {

//    @Autowired
//    SubmissionService submissionService;
//
//    @PostMapping("/submit") // www.codeduel.com/submit
//    public Submission submit(SubmissionRequestMapper submissionRequestMapper){
//        submissionService.submit(submissionRequestMapper);
//    }
}
